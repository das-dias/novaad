# plotting and user control

class GuiApp:
  def __init__(self, device):
    raise NotImplementedError("This is a placeholder for the GUI app")