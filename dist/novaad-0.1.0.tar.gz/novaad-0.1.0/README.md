# novaad
### NOVA-SST Gm/Id Analog/Mixed-Signal IC Design Tool
