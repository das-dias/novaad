# plotting and user control

class GuiApp:
  pass